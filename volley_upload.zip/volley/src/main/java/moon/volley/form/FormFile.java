package moon.volley.form;

/**
 * Created by moon.zhong on 2015/3/2.
 */
public class FormFile {

    private String mName ;

    private String mValue ;

    private String mMime ;
}
