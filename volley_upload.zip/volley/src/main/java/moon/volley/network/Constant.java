package moon.volley.network;

/**
 * Created by gyzhong on 15/3/1.
 */
public interface Constant {

    public final String KugouHost = "http://mobilecdn.kugou.com/api/v3/search/song" ;

    public final String UploadHost = "http://chuantu.biz/upload.php" ;


    public final String MinongHost = "http://www.minongbang.com/test.php" ;
    public final String WeatherHost = "http://api.openweathermap.org/data/2.5/weather" ;
}
